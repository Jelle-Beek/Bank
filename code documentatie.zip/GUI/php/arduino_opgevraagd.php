<?php
include "var.php";

echo $_SESSION['briefjes'];

$_SESSION['briefjes'] = "";
?>
